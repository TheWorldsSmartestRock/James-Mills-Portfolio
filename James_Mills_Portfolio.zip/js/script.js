
// Interactive Script Features
document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to James Mills Portfolio');
});
